<?php
namespace Meigee\Coccinelle\Model;

class CustomLogo extends \Magento\Config\Model\Config\Backend\Image\Logo
{

}
