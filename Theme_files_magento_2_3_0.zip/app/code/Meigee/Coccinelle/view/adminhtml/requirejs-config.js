var config = {
    map: {
        '*': {
			meigeeColorpicker: 'Meigee_Coccinelle/js/jqColorPicker.min'
        }
    }

};




