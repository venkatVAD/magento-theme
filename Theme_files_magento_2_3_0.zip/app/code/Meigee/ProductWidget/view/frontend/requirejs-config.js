var config = {
    map: {
        '*': {
			widgetCarousel: 'Meigee_ProductWidget/js/owl.carousel'
        }
    }

};




